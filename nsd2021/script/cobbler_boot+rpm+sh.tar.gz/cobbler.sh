#!/bin/bash
host_ip=`ip a s ens33 | awk '/inet /{print $2}'`
ens33_ip=${host_ip%/*}
net_segment=${host_ip%.*}
tar -xPf cobbler_boot.tar.gz
#unzip cobbler_rpm.zip
yum -y remove httpd-tools
yum -y remove tftp-server
yum -y install dhcp httpd mod_ssl
cp -p /etc/cobbler/settings /etc/cobbler/settings.bak
cp -p /etc/cobbler/dhcp.template /etc/cobbler/dhcp.template.bak
cd cobbler
yum -y install *.rpm
##修改/etc/cobbler/settings
#cobbler服务器IP是：
sed -i "s/server: 127.0.0.1/server: $ens33_ip/g" /etc/cobbler/settings
#设置cobbler管理DHCP服务
sed -i 's/manage_dhcp: 0/manage_dhcp: 1/g' /etc/cobbler/settings  
#防止客户端重复安装操作系统
sed -i 's/pxe_just_once: 0/pxe_just_once: 1/g' /etc/cobbler/settings
#设置当客户端连接cobbler成功时，对下一跳地址读取tftp内容
sed -i "s/next_server: 127.0.0.1/next_server: $ens33_ip/g" /etc/cobbler/settings

####################
##修改/etc/cobbler/dhcp.template
sed -i "s/192.168.1/$net_segment/g" /etc/cobbler/dhcp.template

systemctl restart cobblerd
systemctl restart httpd
systemctl restart tftp
systemctl restart rsyncd
[ ! -e /dev/cdrom ] && exit
[ -d /var/www/html/dvd ] || mkdir /var/www/html/dvd
mount /dev/cdrom /dvd
cp centos7.5.cfg /var/lib/cobbler/kickstarts/centos7.5.cfg
cobbler import --path=/dvd --name=CentOS7.5 
cobbler rsync
cobbler list
ss -lptuan | grep dhcp
cp sample_end.ks /var/lib/cobbler/kickstarts/sample_end.ks
